#ifndef ELOQUENT_TINYML_H
#define ELOQUENT_TINYML_H

#ifdef ELOQUENT_TFLM
#include "./eloquent_tinyml/tf.h"
#endif

#endif